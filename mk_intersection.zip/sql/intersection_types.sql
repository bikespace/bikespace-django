﻿select count (gid), classifi6, max(classifi7) from intersection2d
   group by classifi6;
select count (gid) from intersection2d;
